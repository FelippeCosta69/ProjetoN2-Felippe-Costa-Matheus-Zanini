
/**
 * Direitos Autorais e Propriedade Intelectual:
 *
 * @author Felippe Costa <Felippecostazan@gmail.com>
 * @date 3 de nov. de 2024
 */
/**
 *
 * @author felip
 */
public class CalculadoraController {
    private CalculadoraModel model;

    public CalculadoraController(CalculadoraModel model) {
        this.model = model;
    }

    public double realizarOperacao(String operacao, double a, double b) {
        switch (operacao) {
            case "+":
                return model.soma(a, b);
            case "-":
                return model.subtracao(a, b);
            case "*":
                return model.multiplicacao(a, b);
            case "/":
                return model.divisao(a, b);
            case "^":
                return model.exponenciacao(a, b);
            case "%":
                return model.porcentagem(a, b);
            default:
                throw new IllegalArgumentException("Operação inválida.");
        }
    }

    public double realizarOperacaoUnaria(String operacao, double a) {
        if ("√".equals(operacao)) {
            return model.raizQuadrada(a);
        }
        throw new IllegalArgumentException("Operação inválida.");
    }

    public void salvarHistorico() {
        model.salvarHistoricoCSV();
    }
}
