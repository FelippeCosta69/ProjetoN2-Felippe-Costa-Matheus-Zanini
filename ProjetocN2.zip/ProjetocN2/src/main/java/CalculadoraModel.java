
/**
 * Direitos Autorais e Propriedade Intelectual:
 *
 * @author Felippe Costa <Felippecostazan@gmail.com>
 * @date 3 de nov. de 2024
 */
/**
 *
 * @author felip
 */
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CalculadoraModel {
    private List<String> historico = new ArrayList<>();

    public double soma(double a, double b) {
        double result = a + b;
        historico.add(a + " + " + b + " = " + result);
        return result;
    }

    public double subtracao(double a, double b) {
        double result = a - b;
        historico.add(a + " - " + b + " = " + result);
        return result;
    }

    public double multiplicacao(double a, double b) {
        double result = a * b;
        historico.add(a + " * " + b + " = " + result);
        return result;
    }

    public double divisao(double a, double b) {
        if (b == 0) {
            historico.add(a + " / " + b + " = ERRO (Divisão por zero)");
            throw new ArithmeticException("Divisão por zero não é permitida.");
        }
        double result = a / b;
        historico.add(a + " / " + b + " = " + result);
        return result;
    }

    public double exponenciacao(double a, double b) {
        double result = Math.pow(a, b);
        historico.add(a + " ^ " + b + " = " + result);
        return result;
    }

    public double raizQuadrada(double a) {
        if (a < 0) {
            historico.add("√" + a + " = ERRO (Raiz quadrada de número negativo)");
            throw new ArithmeticException("Não é possível calcular a raiz quadrada de um número negativo.");
        }
        double result = Math.sqrt(a);
        historico.add("√" + a + " = " + result);
        return result;
    }

    public double porcentagem(double a, double b) {
        double result = (a * b) / 100;
        historico.add(a + "% de " + b + " = " + result);
        return result;
    }

    public void salvarHistoricoCSV() {
        try (FileWriter writer = new FileWriter("historico.csv")) {
            writer.write("Operação,Resultado\n");
            for (String operacao : historico) {
                writer.write(operacao + "\n");
            }
        } catch (IOException e) {
            System.out.println("Erro ao salvar o histórico: " + e.getMessage());
        }
    }
}
