
/**
 * Direitos Autorais e Propriedade Intelectual:
 *
 * @author Felippe Costa <Felippecostazan@gmail.com>
 * @date 3 de nov. de 2024
 */
/**
 *
 * @author felip
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CalculadoraView extends JFrame {
    private JTextField inputField1, inputField2, resultField;
    private CalculadoraController controller;

    public CalculadoraView() {
        controller = new CalculadoraController(new CalculadoraModel());
        setTitle("Calculadora MVC");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(5, 2, 5, 5));

        inputField1 = new JTextField();
        inputField2 = new JTextField();
        resultField = new JTextField();
        resultField.setEditable(false);

        add(new JLabel("Primeiro Número:"));
        add(inputField1);
        add(new JLabel("Segundo Número:"));
        add(inputField2);

        String[] operacoes = {"+", "-", "*", "/", "^", "√", "%"};
        JComboBox<String> operacaoBox = new JComboBox<>(operacoes);
        add(new JLabel("Operação:"));
        add(operacaoBox);

        JButton calcularBtn = new JButton("Calcular");
        calcularBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    String operacao = (String) operacaoBox.getSelectedItem();
                    double num1 = Double.parseDouble(inputField1.getText());
                    double resultado;

                    if ("√".equals(operacao)) {
                        resultado = controller.realizarOperacaoUnaria(operacao, num1);
                    } else {
                        double num2 = Double.parseDouble(inputField2.getText());
                        resultado = controller.realizarOperacao(operacao, num1, num2);
                    }

                    resultField.setText(String.valueOf(resultado));
                } catch (Exception ex) {
                    resultField.setText("Erro: " + ex.getMessage());
                }
            }
        });

        add(calcularBtn);
        add(resultField);

        JButton salvarHistoricoBtn = new JButton("Salvar Histórico");
        salvarHistoricoBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                controller.salvarHistorico();
                JOptionPane.showMessageDialog(null, "Histórico salvo em historico.csv");
            }
        });

        add(salvarHistoricoBtn);

        setSize(400, 250);
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CalculadoraView());
    }
}
